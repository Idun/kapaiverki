// This file is obsolete. Use services/aiService.ts instead.
export {};
